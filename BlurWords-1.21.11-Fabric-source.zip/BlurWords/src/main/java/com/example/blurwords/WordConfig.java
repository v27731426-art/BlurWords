package com.example.blurwords;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class WordConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("blurwords.txt");
    private static final List<String> WORDS = new ArrayList<>();

    private WordConfig() {}

    public static synchronized void load() {
        WORDS.clear();
        try {
            if (Files.exists(FILE)) {
                for (String line : Files.readAllLines(FILE, StandardCharsets.UTF_8)) {
                    String word = line.trim();
                    if (!word.isEmpty() && !word.startsWith("#") && !contains(word)) WORDS.add(word);
                }
            } else {
                save();
            }
        } catch (IOException e) {
            System.err.println("[BlurWords] Could not load config: " + e.getMessage());
        }
    }

    public static synchronized boolean add(String word) {
        if (word == null || word.isBlank() || contains(word.trim())) return false;
        WORDS.add(word.trim());
        save();
        return true;
    }

    public static synchronized boolean remove(String word) {
        boolean removed = WORDS.removeIf(existing -> existing.equalsIgnoreCase(word));
        if (removed) save();
        return removed;
    }

    public static synchronized void clear() {
        WORDS.clear();
        save();
    }

    public static synchronized String listWords() {
        return WORDS.isEmpty() ? "(пусто)" : String.join(", ", WORDS);
    }

    public static synchronized String mask(String input) {
        String result = input;
        for (String word : WORDS) {
            Pattern pattern = Pattern.compile("(?iu)(?<![\\p{L}\\p{N}_])" + Pattern.quote(word) + "(?![\\p{L}\\p{N}_])");
            Matcher matcher = pattern.matcher(result);
            StringBuffer out = new StringBuffer();
            while (matcher.find()) {
                String matched = matcher.group();
                String replacement = "█".repeat(Math.max(1, matched.length()));
                matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
            }
            matcher.appendTail(out);
            result = out.toString();
        }
        return result;
    }

    private static boolean contains(String word) {
        return WORDS.stream().anyMatch(existing -> existing.equalsIgnoreCase(word));
    }

    private static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.write(FILE, WORDS, StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.err.println("[BlurWords] Could not save config: " + e.getMessage());
        }
    }
}
