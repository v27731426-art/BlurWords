package com.example.blurwords;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.minecraft.text.Text;

public class BlurWordsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        WordConfig.load();
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("blurwords")
                .then(ClientCommandManager.literal("add")
                    .then(ClientCommandManager.argument("word", StringArgumentType.greedyString())
                        .executes(context -> {
                            String word = StringArgumentType.getString(context, "word").trim();
                            if (word.isEmpty()) {
                                context.getSource().sendFeedback(Text.literal("Укажи слово: /blurwords add слово"));
                                return 0;
                            }
                            boolean added = WordConfig.add(word);
                            context.getSource().sendFeedback(Text.literal(added
                                ? "Добавлено в список скрытия: " + word
                                : "Это слово уже есть в списке: " + word));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("remove")
                    .then(ClientCommandManager.argument("word", StringArgumentType.greedyString())
                        .executes(context -> {
                            String word = StringArgumentType.getString(context, "word").trim();
                            boolean removed = WordConfig.remove(word);
                            context.getSource().sendFeedback(Text.literal(removed
                                ? "Удалено из списка: " + word
                                : "Такого слова нет в списке: " + word));
                            return removed ? 1 : 0;
                        })))
                .then(ClientCommandManager.literal("list").executes(context -> {
                    context.getSource().sendFeedback(Text.literal("Слова для скрытия: " + WordConfig.listWords()));
                    return 1;
                }))
                .then(ClientCommandManager.literal("clear").executes(context -> {
                    WordConfig.clear();
                    context.getSource().sendFeedback(Text.literal("Список скрытия очищен."));
                    return 1;
                }))
            )
        );
    }
}
