# BlurWords — Minecraft 1.21.11 / Fabric

Client-side chat word masker. It replaces selected whole words with solid block characters (`████`) before they are added to the chat HUD. This is a visual mask, not a true Gaussian blur shader.

## Commands in Minecraft
- `/blurwords add word` — add a word (case-insensitive matching)
- `/blurwords remove word` — remove a word
- `/blurwords list` — show saved words
- `/blurwords clear` — clear the list

Words are saved in `.minecraft/config/blurwords.txt`.

## Build
Requires JDK 21 and Gradle 9.x with internet access to download Fabric/Minecraft build dependencies.

From this folder run:

```bash
gradle build
```

The mod jar will be in `build/libs/`.

## Install
Copy the built jar into the `mods` folder of a Minecraft 1.21.11 Fabric instance. Fabric API is also required.
